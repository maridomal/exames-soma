document.addEventListener('DOMContentLoaded', function () {
  const exames1 = {
    "Dosagem de Ácido Úrico": 1.85,
    "Dosagem de Amilase": 2.25,
    "Dosagem de Cálcio": 1.85,
    "Dosagem de Cálcio Ionizado": 3.51,
    "Dosagem de colesterol HDL": 3.51,
    "Dosagem de colesterol LDL": 3.51,
    "Dosagem de Colesterol Total": 1.85,
    "Dosagem de Creatinina": 1.85,
    "Dosagem de Creatinofosfoquinase": 3.68,
    "Dosagem de Desidrogenas Lática": 3.68,
    "Dosagem de Ferritina": 15.59,
    "Dosagem de Ferro Sérico": 3.51,
    "Dosagem de Fostatase Alcalina": 2.01,
    "Dosagem de Gama-Glutamil-Transferas": 1.85,
    "Dosagem de Glicose": 1.85,
    "Dosagem de Hemoglobina Glicosilada": 7.86,
    "Dosagem de Potássio": 1.85,
    "Dosagem de Proteínas Totais": 1.40,
    "Dosagem de Sódio": 1.85,
    "Dosagem de Transaminase Glutamico-O": 2.01,
    "Dosagem de Transaminase Glutamico- P": 2.01,
    "Dosagem de Triglicerídeos": 3.51,
    "Dosagem de ureia": 1.85,
    "Determinação de tempo e atividade": 2.73,
    "Determinação de Velocidade de Hemossedimentação": 2.73,
    "Hemograma Completo": 4.11,
    "Determinação de fator reumatoide": 2.83,
    "Determinação Quantitativo de Proteína": 9.25,
    "Determinação Quantitativo de Prostático Especifico - PSA": 16.42,
    "Pesquisa de Anticopos Anti-HIV-1": 10.00,
    "Teste não treponemico p/det.": 2.83,
    "Teste não Treponemico p/det. de sífilis Ges": 2.83,
    "Pesquisa de ovos e Cistos de Parasitas": 1.65,
    "Analise de Caracteres Físicos, elementos": 3.70,
    "Dosagem de Gonadotrofina Coriônica": 7.85,
    "Dosagem de Hormônio Tireoestimulante - TSH": 8.96,
    "Dosagem de Tiroxina Livre (T4 Livre)": 11.60,
    "Antibiograma": 4.98,
    "Cultura de Bactéria p/identificação": 5.62,
    "T3 total": 8.71,
    "Vitamina D": 15.24,
    "Toxoplasmose IGG": 16.97,
    "Toxoplasmose IGM": 18.55,
    "Bilirrubinas": 2.01,
    "T4 total": 8.76,
    "Kptt": 5.77
  };

  const exames2 = {
    "Dosagem de Ácido Úrico": 1.85,
    "Bacterioscopia (GRAM)": 2.80,
    "Dosagem de Triglicerídeos": 3.51,
    "Dosagem de colesterol HDL": 3.51,
    "Dosagem de colesterol LDL": 3.51,
    "Dosagem de Colesterol Total": 1.85,
    "Dosagem de Creatinina": 1.85,
    "Dosagem de Creatinofosfoquinase (CPK)": 3.68,
    "Dosagem de Glicose": 1.85,
    "Dosagem de Transaminase Glutamico oxalacética (TGO)": 2.01,
    "Dosagem de Transaminase Glutamico pirúvica (TGP)": 2.01,
    "Dosagem de ureia": 1.85,
    "Determinação do tempo e atividade da Protrombina (TAP)": 2.73,
    "Hemograma Completo": 4.11,
    "Dosagem de antigeno Prostático Especifico (PSA)": 16.42,
    "Analise de Caracteres Físicos, elementos e sedimentos da Urina": 3.70,
    "Dosagem de Gonadotrofina Coriônica Humana (BHCG)": 7.85,
    "Dosagem de Hormônio Tireoestimulante (TSH)": 8.96,
    "Dosagem de Tiroxina Livre (T4 Livre)": 11.60,
    "Dosagem de Triiodotironina (T3)": 8.71,
    "Dosagem de Tiroxina (T4)": 8.76
  };

  function criarCalculadora(exames, containerId, totalQtdId, totalValId, atualizarFuncName) {
    const container = document.getElementById(containerId);
    const totalQtdEl = document.getElementById(totalQtdId);
    const totalValEl = document.getElementById(totalValId);

    Object.entries(exames).forEach(([nome, preco]) => {
      const div = document.createElement('div');
      div.className = 'exame';

      div.innerHTML = `
        <label>
          <input type="checkbox" class="${containerId}-checkbox" onchange="${atualizarFuncName}()"> 
          ${nome} — R$ ${preco.toFixed(2)}
        </label>
        <input type="number" min="1" value="1" disabled class="exame-quantidade" onchange="${atualizarFuncName}()" />
      `;

      container.appendChild(div);
    });

    window[atualizarFuncName] = function () {
      const checkboxes = document.querySelectorAll(`.${containerId}-checkbox`);
      let totalExames = 0;
      let totalValor = 0;

      checkboxes.forEach(checkbox => {
        const divExame = checkbox.closest('.exame');
        const inputQtd = divExame.querySelector('.exame-quantidade');
        const preco = parseFloat(divExame.querySelector('label').textContent.match(/R\$ (\d+,\d+|\d+\.\d+)/)[1].replace(',', '.'));
        inputQtd.disabled = !checkbox.checked;

        if (checkbox.checked) {
          const quantidade = parseInt(inputQtd.value) || 1;
          totalExames += quantidade;
          totalValor += preco * quantidade;
        }
      });

      totalQtdEl.textContent = `Total de exames: ${totalExames}`;
      totalValEl.textContent = `Valor total: R$ ${totalValor.toFixed(2)}`;
    };
  }

  criarCalculadora(exames1, 'exames-container-1', 'quantidade-total-1', 'valor-total-1', 'atualizarTotal1');
  criarCalculadora(exames2, 'exames-container-2', 'quantidade-total-2', 'valor-total-2', 'atualizarTotal2');
});
